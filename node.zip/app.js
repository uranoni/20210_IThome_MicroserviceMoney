var express = require('express')
var sha256 = require('js-sha256');
var _ = require('lodash')
var app = express()
var axios = require('axios')
const {
  scrypt,
  randomFill,
  createCipheriv
} = require('crypto');
app.use(express.json()) // for parsing application/json
app.use(express.urlencoded({ extended: true })) // for parsing application/x-www-form-urlencoded

const nonce = 'NjM2NjY5MDQ3OTQwMzIuMTphZmJjODBhOTM5NzQ1NjMyNDFhZTczMjVjYzg0Mjg5ZjQxYTk2MWI2ZjNkYTA0NDdmOTRhZjU3ZTIzOWJlNDgz'
const hashid = 	'4DA70F5E2D800D50B43ED3B537480C64'
const msg = `{"ShopNo":"NA0001_001","OrderNo":"201807111119291750","Amount":50000,"CurrencyID":"TWD","PayType":"C","ATMParam":{},"CardParam":{"AutoBilling":"N","ExpMinutes":30},"PrdtName":"信用卡訂單","ReturnURL":"http://10.11.22.113:8803/QPay.ApiClient-Sandbox/Store/Return","BackendURL":"https://sandbox.sinopac.com/funBIZ.ApiClient/AutoPush/PushSuccess"}`
function xor(hex1, hex2) {
  const buf1 = Buffer.from(hex1, 'hex');
  const buf2 = Buffer.from(hex2, 'hex');
  const bufResult = buf1.map((b, i) => b ^ buf2[i]);
  return bufResult.toString('hex');
}

function sign(my_object){
  var result = _.omitBy(
    my_object,
    (v) => _.isUndefined(v) || _.isNull(v) || v === ""
  );
  
  var resultkeys = _.without(_.keys(result), "").sort();
  var hashstring = resultkeys.reduce((acc, cur, idx) => {
    if (idx == resultkeys.length - 1) {
      return acc + `${cur}=${result[cur]}`;
    }
    return acc + `${cur}=${result[cur]}&`;
  }, "");
  return hashstring
}

app.post('/hashid', function (req, res, next) {
	const a = xor(req.body.A1,req.body.A2)
	const b = xor(req.body.B1,req.body.B2)
	const result =  a + b
  res.send(result.toLocaleUpperCase())
})

app.post('/sign', function (req, res, next) {
	console.log(req.body)
  var result = sign(req.body)
  const hashrr = result+nonce+hashid
  const hashresult = sha256(result+nonce+hashid)
  res.send(hashresult.toLocaleUpperCase())
})

app.post('/message', async function (req, res, next) {
  const IV = sha256(nonce).substr(-16,16).toLocaleUpperCase() 
  const cipher = createCipheriv('aes-256-cbc',hashid, IV);
  let encrypted = cipher.update(msg, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const result = encrypted.toLocaleUpperCase()
  console.log(encrypted);
  
  res.send(result)
})

app.listen(8888)
